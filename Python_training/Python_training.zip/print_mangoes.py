# -*- coding: utf-8 -*-
"""
Created on Wed Dec 19 13:43:26 2018

@author: calydon
"""

print(23 + 23 + 23 + 23,"runs")
print("good")