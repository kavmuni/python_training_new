# -*- coding: utf-8 -*-
"""
Created on Wed Dec 19 15:28:30 2018

@author: calydon
"""

"""This program is used to get the 4th innings total"""