# -*- coding: utf-8 -*-
"""
Created on Thu Dec 20 09:45:00 2018

@author: calydon
"""

fruits="apples"
dozen=250
price=250/12
print(f"The price of 1 {fruits[:-1]} is {price}")
print(f"The price of 10 {fruits[:-1]} is {round(10*price,2)}")