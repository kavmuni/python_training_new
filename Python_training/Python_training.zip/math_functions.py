# -*- coding: utf-8 -*-
"""
Created on Thu Dec 20 10:12:51 2018

@author: calydon
"""

import math as mt
for method in dir(mt):
    print(method)