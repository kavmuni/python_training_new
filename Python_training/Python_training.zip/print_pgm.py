'''This is for documentation'''
print("hello","world")
